package bioseq.core;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class CoreSmokeTest {
  @Test
  void smoke() {
    assertTrue(true);
  }
}
