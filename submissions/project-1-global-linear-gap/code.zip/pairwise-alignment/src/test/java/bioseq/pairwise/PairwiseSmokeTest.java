package bioseq.pairwise;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class PairwiseSmokeTest {
  @Test
  void smoke() {
    assertTrue(true);
  }
}
