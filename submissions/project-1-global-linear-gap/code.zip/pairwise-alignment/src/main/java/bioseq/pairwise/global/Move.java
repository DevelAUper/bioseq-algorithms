package bioseq.pairwise.global;

/**
 * Traceback move for global alignment DP.
 */
public enum Move {
  DIAG,
  UP,
  LEFT
}
